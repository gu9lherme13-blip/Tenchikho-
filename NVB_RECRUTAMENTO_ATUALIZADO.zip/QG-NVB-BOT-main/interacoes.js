// Ações editáveis do comando /interacao.
const INTERACTION_CHOICES = [
  {name:'🫂 Abraçar',value:'abracar'}, {name:'💋 Beijar',value:'beijar'},
  {name:'🩸 Morder',value:'morder'}, {name:'🛡️ Proteger',value:'proteger'},
  {name:'⚔️ Atacar',value:'atacar'}, {name:'✨ Curar',value:'curar'},
  {name:'🔥 Rival',value:'rival'}, {name:'🍖 Comer',value:'comer'},
  {name:'💬 Conversar',value:'conversar'}, {name:'🤝 Ajudar',value:'ajudar'},
  {name:'😴 Dormir',value:'dormir'}, {name:'😂 Rir',value:'rir'},
  {name:'👀 Desafiar',value:'desafiar'}, {name:'🥊 Treinar',value:'treinar'},
  {name:'🎉 Parabenizar',value:'parabenizar'}
];
module.exports = {INTERACTION_CHOICES};
