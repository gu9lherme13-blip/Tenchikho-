# Comandos oficiais — NVB

Esta versão registra somente os comandos abaixo.

> Observação: o Discord não permite espaços ou acentos em nomes de slash commands. Por isso, os nomes aparecem normalizados com `-` e sem acentos.

## Membro
- `/nvb`
- `/perfil`
- `/roblox`
- `/avatar`
- `/avatar-roblox`
- `/cargos`
- `/conquistas`
- `/nivel`
- `/pontos`
- `/ranking`
- `/status`
- `/ajuda`

## Recrutamento
- `/recrutamento` — gera um código único de recrutamento e o link do QG para a pessoa recrutada
- `/aprovar`
- `/recusar`

## Moderação / Administração
- `/aviso`
- `/silenciar`
- `/dessilenciar`
- `/expulsar`
- `/banir`
- `/desbanir`
- `/limpar`
- `/historico`
- `/dar-cargo`
- `/remover-cargo`
- `/logs`

## Pontos / Conquistas
- `/conquista-add`
- `/pontos-add`
- `/pontos-remove`
- `/recompensa`
- `/presenca`

## Comunidade
- `/chamada`
- `/evento`
- `/jogatina`
- `/resenha`
- `/gravacao`
- `/edicao`
- `/musica`

## Interações animais
- `/interacao-animal-anfibios`
- `/interacao-animal-aves`
- `/interacao-animal-insetos`
- `/interacao-animal-mamiferos`
- `/interacao-animal-maritimas`
- `/interacao-animal-repteis`

## Multiverso / Personagens
- `/interacao-multiverso`
- `/personagem-anime`
- `/personagem-dc`
- `/personagem-desenhos`
- `/personagem-filmes`
- `/personagem-hq`
- `/personagem-jogos`
- `/personagem-marvel`
- `/personagem-outros`
- `/personagem-series`
- `/duelo-multiverso`
- `/energia-multiverso`
- `/multiversoquiz`

## Social
- `/ship`

**Total desta lista: 58 comandos.**
