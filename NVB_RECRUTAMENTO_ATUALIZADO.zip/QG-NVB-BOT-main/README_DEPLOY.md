# NVB BOT — versão limpa de comandos

Esta versão foi organizada para evitar o problema de comandos antigos voltando a aparecer.

## O que mudou

- Existe somente um `index.js` principal neste pacote.
- O registro de slash commands substitui a lista do servidor pela lista oficial desta versão.
- Os comandos globais antigos são limpos quando `GUILD_ID` está configurado.
- Comandos antigos de candidatura, skin, configuração, entrada/saída, autocargo, anúncio automático, painel, verificação, setcargo, trancar/destrancar e similares não são registrados nesta versão.
- A lista oficial fica documentada em `COMANDOS_OFICIAIS.md`.

## Atenção aos dados

O ZIP usado como base nesta correção continha `index.js`, `index.html`, `package.json` e este README. Os arquivos de dados que aparecem no repositório original (por exemplo `pontos.json`, `xp.json`, `roblox.json`, `presenca.json`, `recompensas.json`, `historico.json` e outros) **não foram apagados nem recriados por esta correção**; eles simplesmente não faziam parte do ZIP recebido para esta montagem.

Ao substituir o código no GitHub, mantenha os arquivos `.json` de dados que já existem no seu repositório.

## Instalação

```bash
npm install
npm start
```

Use as mesmas variáveis de ambiente do projeto atual (`TOKEN`, `CLIENT_ID`, `GUILD_ID` e IDs de cargos/canais já utilizados pelo bot).

## Importante sobre comandos antigos

Se os comandos antigos continuarem aparecendo, não execute uma versão antiga do `index.js` e não mantenha outro `index.js` como arquivo principal. O bot deve iniciar somente com o `index.js` desta versão.

Quando `GUILD_ID` estiver configurado, os comandos do servidor são registrados diretamente nele. Se `GUILD_ID` não estiver configurado, o registro é global e pode demorar para refletir alterações no Discord.
